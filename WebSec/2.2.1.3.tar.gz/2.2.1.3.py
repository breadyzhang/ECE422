import hashlib
import random

target = b"'=0#"
test = "huh"
counter = 0
while target not in hashlib.md5(bytes(test, 'utf-8')).digest():
    test = str(random.randint(1,9999999999999999))
    counter += 1
print('DONE')
print(test)
print(counter, ' attempts')
